var mentee = [{
    name:'Fathi',
    email:'k@gmail.com',
    phone :'012345678'
}
]
var mentor = {

}

export {mentee, mentor}